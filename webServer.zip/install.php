<?php
    require("config.inc.php");
    $sql_create_db = 'CREATE DATABASE ' . $db_name;
    mysql_query($sql_create_db, $connect) or die(mysql_error());
        echo "Database " . $db_name . " created successfully<br/>";
	mysql_select_db($db_name) or die(mysql_error());
    $sql_create_tb = 'CREATE TABLE IF NOT EXISTS '. $tb_name .'
            (
                username        varchar(50)     NOT NULL,
                password        varchar(50)     NOT NULL,
                email           varchar(50)     NOT NULL,
                PRIMARY KEY (username)
            );';
    mysql_query($sql_create_tb, $connect) or die(mysql_error());
        echo "Table " . $tb_name . " created successfully\n";
?>
