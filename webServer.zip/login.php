<?php
    require("config.inc.php");
    mysql_select_db($db_name) or die(mysql_error());
    $flag['code'] = 0;
    $username = $_REQUEST['username'];
    $password = $_REQUEST['password'];
    
    if(isset($username,$password)){
        $sql_check = " SELECT * FROM $tb_name
                       WHERE username = '" . $username . "' AND
                             password = '" . $password . "'";
        $flag_err['code'] = 0;
        $flag_err = json_encode($flag_err);
        $result = mysql_query($sql_check, $connect);
        $count = mysql_num_rows($result);
        if($count == 1){
            $flag['code'] = 1;
            print(json_encode($flag));
        }else{
            print $flag_err;
        }
    }
    mysql_close($connect);
?>