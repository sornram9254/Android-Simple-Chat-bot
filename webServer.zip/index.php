<?php
    require("config.inc.php");
    error_reporting(E_ALL ^ E_NOTICE);
    mysql_select_db($db_name) or die(mysql_error());
    $flag['code'] = 0;
    $username = $_REQUEST['username'];
    $password = $_REQUEST['password'];
    $email    = $_REQUEST['email'];
    
    if(isset($username,$password,$email)){
        $sql_insert = "INSERT INTO $tb_name
            (
                username,
                password,
                email
            )
            VALUES
            (
                '$username',
                '$password',
                '$email'
            );";
        $flag_err['code'] = 0;
        $flag_err = json_encode($flag_err);
        $result = mysql_query($sql_insert, $connect) or die(print $flag_err);
        if($result){
            $flag['code'] = 1;
            print(json_encode($flag));
        }
    }
    mysql_close($connect);
?>