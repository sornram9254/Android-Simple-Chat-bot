<?php
    $host       = "localhost";
    $mysql_user = "root";
    $mysql_pass = "";
    $db_name    = "project";
    $tb_name    = "user";
	$connect = mysql_connect($host, $mysql_user, $mysql_pass) or die(mysql_error());
?>